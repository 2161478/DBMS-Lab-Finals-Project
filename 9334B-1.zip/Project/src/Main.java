import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    private static DBController controller;
    private static Scanner kbd = new Scanner(System.in);

    public static void main(String[] args) {
	controller = new DBController();
	try {
	    int choice;
	    String url = "jdbc:mysql://localhost/group1?useSSL=false";
	    controller.dbaseConnect(url, "root", null);
	    while (true) {
		choice = showMenu();
		if (choice == 19) {
		    System.out.println("Thank your for trying this program...");
		    break;
		}
		processChoice(choice);
	    }
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	} finally {
	    controller.close();
	}
    }

    private static void processChoice(int option) {
	switch (option) {
	case 1:
	    printAllEmployees();
	    break;
	case 2:
	    printAllProjects();
	    break;
	case 3:
	    printAllDepartments();
	    break;
	case 4:
	    printAllProjectEmployee();
	    break;
	case 5:
	    printAllEmployeeProject();
	    break;
	case 6:
	    printAllEmployeesOfDepartment();
	    break;
	case 7:
	    addEmployee();
	    break;
	case 8:
	    addProject();
	    break;
	case 9:
	    addDepartment();
	    break;
	case 10:
	    addEmpProj();
	    break;
	case 11:
	    deleteEmployee();
	    break;
	case 12:
	    deleteDepartment();
	    break;
	case 13:
	    deleteProject();
	    break;
	case 14:
	    deleteEmpProj();
	case 15:
	    editEmployee();
	    break;
	case 16:
	    editDepartment();
	    break;
	case 17:
	    editProject();
	    break;
	case 18:
	    editEmployeeProject();
	    break;
	default:
	    System.out.println("From numbers 1 to 19 only!");
	}
    }

    private static int showMenu()// check if this syncs with the switch cases
    {
	int choice = 0;
	do {
	    System.out.println("+-------------------------------------------+");
	    System.out.println("|   M E N U  O P T I O N S                  |");
	    System.out.println("+-------------------------------------------+");
	    System.out.println("| 1. Show all Employees                     |");
	    System.out.println("| 2. Show all Projects                      |");
	    System.out.println("| 3. Show all Departments                   |");
	    System.out.println("| 4. Show Employees working on a project    |");
	    System.out.println("| 5. Show Projects an Employee is working on|");
	    System.out.println("| 6. Print all employees from a department  |");
	    System.out.println("| 7. Add an Employee                        |");
	    System.out.println("| 8. Add a Project                          |");
	    System.out.println("| 9. Add a Department                       |");
	    System.out.println("| 10.Add an Employee Project                |");
	    System.out.println("| 11.Delete an Employee                     |");
	    System.out.println("| 12.Delete a Department                    |");
	    System.out.println("| 13.Delete a Project                       |");
	    System.out.println("| 14.Delete an Employee Project             |");
	    System.out.println("| 15.Update an Employee                     |");
	    System.out.println("| 16.Update a Department                    |");
	    System.out.println("| 17.Update a Project                       |");
	    System.out.println("| 18.Update an Employee Project             |");
	    System.out.println("| 19.Exit program                           |");
	    System.out.println("+-------------------------------------------+");
	    System.out.print("Enter your choice: ");
	    try {
		choice = Integer.parseInt(kbd.nextLine());
	    } catch (Exception e) {
		System.out.println("error: input a valid value...");
		System.out.print("Press enter key to continue...");
		// kbd.nextLine();
	    }
	    System.out.println();
	} while (choice < 1 || choice > 18);
	return choice;
    }

    private static void printAllEmployees() { // prints all employees - case 1
	printDivider();
	try {
	    ResultSet rs = controller.getAllEmployee();
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: no records found!!!");
	    } else {
		System.out.println("Employee listing:");
		System.out.printf("     %-20s %-20s %-20s %-20s %-20s %-20s%n", "Name", "Job", "Hire Date", "Birth Day",
			"Manager", "Department");
		int row = 1;
		while (rs.next()) {
		    String name = rs.getString(1);
		    String job = filterNull(rs.getString(2));
		    String hiredate = filterNull(rs.getString(3));
		    String bday = rs.getString(4);
		    String manager = filterNull(rs.getString(5));
		    String department = filterNull(rs.getString(6));
		    System.out.printf("%-4d %-20s %-20s %-20s %-20s %-20s %-20s%n", row++, name, job, hiredate, bday,
			    manager, department);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printAllProjects() { // prints all projects - case2
	printDivider();
	try {
	    ResultSet rs = controller.getAllProject();
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: no records found!!!");
	    } else {
		System.out.println("Project listing:");
		System.out.printf("     %-20s %-20s %-20s%n", "Project Name", "Status", "Department");
		int row = 1;
		while (rs.next()) {
		    String name = rs.getString(1);
		    String status = filterNull(rs.getString(2));
		    String department = filterNull(rs.getString(3));
		    System.out.printf("%-4d %-20s %-20s %-20s%n", row++, name, status, department);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printAllDepartments() { // prints all departments - case 3
	printDivider();
	try {
	    ResultSet rs = controller.getAllDepartment();
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: no records found!!!");
	    } else {
		System.out.println("Department listing:");
		System.out.printf("     %-20s%n", "Department");
		int row = 1;
		while (rs.next()) {
		    String name = rs.getString(1);
		    System.out.printf("%-4d %-20s%n", row++, name);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printAllProjectEmployee() { // prints all employees working on a project - case 4
	printDivider();
	try {
	    System.out.print("Enter name of the project: ");
	    String projName = kbd.nextLine();
	    ResultSet rs = controller.getProjectEmployee(projName);
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: no records found!!!");
	    } else {
		System.out.println("Employees working in Project " + projName + ": ");
		System.out.printf("     %-20s %-20s %-20s%n", "Employees", "Date Started", "Hourly Rate");
		int row = 1;
		while (rs.next()) {
		    String name = rs.getString(1);
		    String dateStarted = filterNull(rs.getString(2));
		    String hourlyRate = filterNull(rs.getString(3));
		    System.out.printf("%-4d %-20s %-20s %-20s%n", row++, name, dateStarted, hourlyRate);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printAllEmployeeProject() { // prints all projects an employee is working on case 5
	printDivider();
	try {
	    System.out.print("Enter name of the employee: ");
	    String empName = kbd.nextLine();
	    ResultSet rs = controller.getEmployeeProject(empName);
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: no records found!!!");
	    } else {
		System.out.println("Projects " + empName + " is working on: ");
		System.out.printf("     %-20s %-20s %-20s%n", "Project", "Date Started", "Hourly Rate");
		int row = 1;
		while (rs.next()) {
		    String project = rs.getString(1);
		    String dateStarted = filterNull(rs.getString(2));
		    String hourlyRate = filterNull(rs.getString(3));
		    System.out.printf("%-4d %-20s %-20s %-20s%n", row++, project, dateStarted, hourlyRate);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printAllEmployeesOfDepartment() { // prints all employees from a department - case 6
	printDivider();
	try {
	    System.out.print("Enter name of the department: ");
	    String deptName = kbd.nextLine();
	    ResultSet rs = controller.getEmployeesFromDepartment(deptName);
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: no records found!!!");
	    } else {
		System.out.println("Employees from " + deptName + " department: ");
		System.out.printf("     %-20s %-20s %-20s%-20s %-20s %-20s%n", "Employee ID", "Name", "Job",
			"Hire Date", "Birth Date", "Manager");
		int row = 1;
		while (rs.next()) {
		    String empid = rs.getString(1);
		    String name = rs.getString(2);
		    String job = rs.getString(3);
		    String hiredate = rs.getString(4);
		    String birthdate = rs.getString(5);
		    String manager = filterNull(rs.getString(6));
		    System.out.printf("%-4d %-20s %-20s %-20s%-20s %-20s %-20s%n", row++, empid, name, job, hiredate,
			    birthdate, manager);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void addEmployee() { // case 7
	// printDivider();

	System.out.print("Enter name: ");
	String name = kbd.nextLine();

	System.out.print("Enter job: ");
	String job = kbd.nextLine();

	System.out.print("Enter hiredate (Ex:2017-05-02) :");
	String hiredate = kbd.nextLine();

	System.out.print("Enter bday: (Ex:1998-05-02): ");
	String bday = kbd.nextLine();
	System.out.print("Enter manager id (Ex: 1): ");
	String managerid = kbd.nextLine();

	System.out.print("Enter department id (Ex: 1): ");
	String department = kbd.nextLine();

	try {
	    controller.createEmployee(name, job, hiredate, bday, managerid, department);
	} catch (SQLException e) {
	    e.printStackTrace();
	}
	System.out.println(name + " was successfully added in the employee list.");
	printDivider();
	System.out.println();
    }

    private static void addProject() { // case 8
	// printDivider();
	System.out.print("Enter Project Name: ");
	String name = kbd.nextLine();
	System.out.print("Enter Status of the Project: ");
	String status = kbd.nextLine();
	System.out.print("Enter Department in which the project belongs: ");
	String deptid = kbd.nextLine();
	System.out.print("Enter Project Head: ");
	String projHead = kbd.nextLine();

	try {
	    controller.createProject(name, status, deptid, projHead);
	} catch (SQLException e) {
	    e.printStackTrace();
	}
	System.out.println(name + " was successfully added in the project list.");
	printDivider();
	System.out.println();
    }

    private static void addDepartment() { // case 9
	// printDivider();
	System.out.print("Enter Department Name: ");
	String name = kbd.nextLine();

	try {
	    controller.createDepartment(name);
	} catch (SQLException e) {
	    e.printStackTrace();
	}
	System.out.println(name + " was successfully added in the department list.");
	printDivider();
	System.out.println();
    }

    private static void addEmpProj() { // case 10
	System.out.print("Enter employee id: ");
	int empID = Integer.parseInt(kbd.nextLine());
	System.out.print("Enter project id: ");
	int projID = Integer.parseInt(kbd.nextLine());
	System.out.print("Enter hour rate: ");
	double hrRate = Double.parseDouble(kbd.nextLine());
	System.out.print("Enter start date of employee (Ex:2017-05-02): ");
	String startDate = kbd.nextLine();
	try {
	    controller.createEmployeeProject(empID, projID, startDate, hrRate);
	} catch (Exception e) {
	    e.printStackTrace();
	}
	System.out.println("Successfully added in the employee project list.");
	printDivider();
	System.out.println();
    }

    private static void deleteEmployee() { // case 11
	printDivider();
	try {
	    String name = input("Enter the exact name of the employee to be deleted: ");
	    ResultSet rs = controller.searchEmployeeInfo(name);
	    if (getResTotal(rs) == 0) {
		System.out.println("error: ID not found. Please enter an existing employee id.");
		deleteEmployee();
	    }
	    controller.deleteEmployee(name);
	    System.out.println(name + " was successfully deleted from the employee list.");
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void deleteDepartment() { // case 12
	printDivider();
	try {
	    String name = input("Enter the exact name of the department to be deleted: ");
	    ResultSet rs = controller.searchDepartmentInfo(name);
	    if (getResTotal(rs) == 0) {
		System.out.println("error: ID not found. Please enter an existing department id.");
		deleteDepartment();
	    }
	    controller.deleteDepartment(name);
	    System.out.println(name + " was successfully deleted from the department list.");
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void deleteProject() { // case 13
	printDivider();
	try {
	    String name = input("Enter the exact name of the project to be deleted: ");
	    ResultSet rs = controller.searchProjectInfo(name);
	    if (getResTotal(rs) == 0) {
		System.out.println("error: ID not found. Please enter an existing project id.");
		deleteProject();
	    }
	    controller.deleteProject(name);
	    System.out.println(name + " was successfully deleted from the project list.");
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void deleteEmpProj() { // case 14
	printDivider();
	try {
	    System.out.println("Enter the necessary information of record.");
	    String name1 = input("Enter the exact name of the employee: ");
	    String name2 = input("Enter the exact name of the project: ");
	    ResultSet rs = controller.searchEmpProjInfo(name1, name2);
	    if (getResTotal(rs) == 0) {
		System.out.println("error: Record not found. Please enter an existing record");
		deleteEmpProj();
	    }
	    controller.deleteEmpProj(name1, name2);
	    System.out.println("The record of employee with Id " + name1 + " who has a project with Id " + name2
		    + " was successfully deleted from the record.");
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static String input(String prompt) {
	String input;
	System.out.println(prompt);
	input = kbd.nextLine();
	return input;
    }

    private static int getResTotal(ResultSet rs) throws Exception {
	int count;
	rs.last();
	count = rs.getRow();
	rs.beforeFirst();
	return count;
    }

    // ================================= employee
    // =======================================
    private static void editEmployee() { // csae 15
	printDivider();
	try {
	    String ename;
	    ResultSet rs;
	    do {
		ename = inputName("Enter exact name of employee to be edited: ");
		rs = controller.searchEmployeeInfo(ename);
		if (getResTotal(rs) == 0) {
		    System.out.println("error: Name not found. Please enter an existing employee name.");
		}
	    } while (getResTotal(rs) == 0);
	    rs = controller.searchEmployeeInfo(ename);
	    printEmployee(rs);
	    rs.beforeFirst();
	    String col = enterEmployeeColumn();
	    String rValue;
	    System.out.print("Enter replacement value: ");
	    rValue = kbd.nextLine();
	    controller.updateEmployee(ename, col, rValue);
	    if (col.equals("name")) {
		rs = controller.searchEmployeeInfo(rValue);
	    } else {
		rs = controller.searchEmployeeInfo(ename);
	    }
	    printEmployee(rs);
	    rs.close();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printEmployee(ResultSet rs) {
	try {
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: name not found!!!");
	    } else {
		printDivider();
		System.out.printf("     %-20s %-20s %-20s %-20s %-20s %-20s%n", "Name", "Job", "Hire Date", "Birth Day",
			"Manager", "Department");
		int row = 1;
		while (rs.next()) {
		    String ename = rs.getString("ename");
		    String job = rs.getString("job");
		    String hiredate = rs.getString("hiredate");
		    String bday = rs.getString("bday");
		    String manager = rs.getString("mgrid");
		    String department = rs.getString("deptid");
		    System.out.printf("%-4d %-20s %-20s %-20s %-20s %-20s %-20s%n", row++, ename, job, hiredate, bday,
			    manager, department);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static String enterEmployeeColumn() {
	String col;
	boolean valid = false;
	do {
	    System.out.print("Enter the column name you would like edit: ");
	    col = kbd.nextLine().toLowerCase();
	    switch (col) {
	    case "name":
	    case "job":
	    case "hire date":
	    case "birth day":
	    case "manager":
	    case "department":
		valid = true;
	    }
	} while (!valid);
	col = reformatEmployeeColumnn(col);
	return col;
    }

    private static String reformatEmployeeColumnn(String col) {
	switch (col) {
	case "name":
	    col = "ename";
	    break;
	case "hire date":
	    col = "hiredate";
	    break;
	case "manager":
	    col = "mgrid";
	    break;
	case "department":
	    col = "deptid";
	    break;
	case "birth day":
	    col = "bday";
	    break;
	}
	return col;
    }

    // ================================= department
    // =======================================
    private static void editDepartment() { // case 16
	printDivider();
	try {
	    String dname;
	    ResultSet rs;
	    do {
		dname = inputName("Enter exact name of the department to be edited: ");
		rs = controller.searchDepartmentInfo(dname);
		if (getResTotal(rs) == 0) {
		    System.out.println("error: Name not found. Please enter an existing contact name.");
		}
	    } while (getResTotal(rs) == 0);
	    rs = controller.searchDepartmentInfo(dname);
	    printAllDepartments();
	    rs.beforeFirst();
	    String rValue;
	    System.out.print("Enter replacement value: ");
	    rValue = kbd.nextLine();
	    controller.updateDepartment(dname, rValue);
	    printAllDepartments();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    // ================================= project
    // =======================================
    private static void editProject() { // case 17
	printDivider();
	try {
	    String pname;
	    ResultSet rs;
	    do {
		pname = inputName("Enter exact name of project to be edited: ");
		rs = controller.searchProjectInfo(pname);
		if (getResTotal(rs) == 0) {
		    System.out.println("error: Name not found. Please enter an existing project name.");
		}
	    } while (getResTotal(rs) == 0);
	    rs = controller.searchProjectInfo(pname);
	    printProject(rs);
	    rs.beforeFirst();
	    String col = enterProjectColumn();
	    String rValue;
	    System.out.print("Enter replacement value: ");
	    rValue = kbd.nextLine();
	    controller.updateProject(pname, col, rValue);
	    rs = controller.searchProjectInfo(pname);
	    printProject(rs);
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printProject(ResultSet rs) { // case 18
	try {
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: name not found!!!");
	    } else {
		printDivider();
		System.out.printf("     %-20s %-20s %-20s %-20s %n", "Project Name", "Status", "Department",
			"Project Head");
		int row = 1;
		while (rs.next()) {
		    String projname = rs.getString("projname");
		    String status = rs.getString("status");
		    String department = rs.getString("dept");
		    String projectHead = rs.getString("projHead");
		    System.out.printf("%-4d %-20s %-20s %-20s %-20s %n", row++, projname, status, department,
			    projectHead);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static String enterProjectColumn() {
	String col;
	boolean valid = false;
	do {
	    System.out.print("Enter the column name you would like edit: ");
	    col = kbd.nextLine().toLowerCase();
	    switch (col) {
	    case "project name":
	    case "status":
	    case "department":
	    case "project head":
		valid = true;
	    }
	} while (!valid);
	col = reformatProjectColumn(col);
	return col;
    }

    private static String reformatProjectColumn(String col) {
	switch (col) {
	case "project name":
	    col = "projname";
	    break;
	case "department":
	    col = "dept";
	    break;
	case "project head":
	    col = "projhead";
	    break;
	}
	return col;
    }

    // ================================= employee - project
    // =======================================

    private static void editEmployeeProject() {
	printDivider();
	try {
	    String empid;
	    String projid;
	    ResultSet rs;
	    do {
		empid = inputName("Enter exact id of employee to be edited: ");
		projid = inputName("Enter exact id of project to be edited: ");
		rs = controller.searchEmpProjInfo(empid, projid);
		if (getResTotal(rs) == 0) {
		    System.out.println("error: Date not found. Please enter an existing start date.");
		}
	    } while (getResTotal(rs) == 0);
	    rs = controller.searchEmpProjInfo(empid, projid);
	    printEmployeeProject(rs);
	    rs.beforeFirst();
	    String col = enterColumn();
	    String rValue;
	    System.out.print("Enter replacement value: ");
	    rValue = kbd.nextLine();
	    controller.updateEmpProj(empid, projid, col, rValue);
	    if (col.equals("empid")) {
		rs = controller.searchEmpProjInfo(rValue, projid);
	    } else if (col.equals(projid)) {
		rs = controller.searchEmpProjInfo(empid, rValue);
	    } else {
		rs = controller.searchEmpProjInfo(empid, projid);
	    }
	    printEmployeeProject(rs);
	    rs.close();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static void printEmployeeProject(ResultSet rs) {
	try {
	    if (getResTotal(rs) == 0) {
		System.out.println("Error: start date not found!!!");
	    } else {
		printDivider();
		System.out.printf("     %-20s %-20s %-20s %-20s%n", "empid", "projid", "startdate", "hourlyrate");
		int row = 1;
		while (rs.next()) {
		    String empid = rs.getString("empid");
		    String projid = rs.getString("projid");
		    String startdate = rs.getString("startdate");
		    String hourlyrate = rs.getString("hourlyrate");
		    System.out.printf("%-4d %-20s %-20s %-20s %-20s%n", row++, empid, projid, startdate, hourlyrate);
		}
	    }
	    printDivider();
	    System.out.println();
	} catch (Exception e) {
	    System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
	}
    }

    private static String enterColumn() {
	String col;
	boolean valid = false;
	do {
	    System.out.print("Enter the column name you would like edit: ");
	    col = kbd.nextLine().toLowerCase();
	    switch (col) {
	    case "empid":
	    case "projid":
	    case "startdate":
	    case "hourlyrate":
		valid = true;
	    }
	} while (!valid);
	return col;
    }

    // ========================================================================================================================
    private static String inputName(String prompt) {
	String input;
	boolean valid;
	do {
	    System.out.print(prompt);
	    input = kbd.nextLine();
	    valid = input.matches("[a-zA-Z_ -.]{1,15}");
	} while (!valid);
	return input;
    }

    private static String filterNull(String str) {
	return str == null ? "" : str;
    }

    private static void printDivider() {
	for (int i = 1; i <= 120; i++) {
	    System.out.print("*");
	}
	System.out.println();
    }
}
